import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        String inputFile = "fuente.txt";
        String outputFile = "output.txt";
        List<String> errors = new ArrayList<>();

        List<Token> tokens = Lexer.tokenize(inputFile, errors);
        Parser parser = new Parser(tokens, errors);
        parser.parse();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            for (Token token : tokens) {
                writer.write(token.toString());
                writer.newLine();
            }
            writer.newLine();
            for (String error : errors) {
                writer.write(error);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
