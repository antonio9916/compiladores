import java.util.List;

public class Parser {
    private List<Token> tokens;
    private int currentTokenIndex;
    private Token currentToken;
    private List<String> errors;

    public Parser(List<Token> tokens, List<String> errors) {
        this.tokens = tokens;
        this.currentTokenIndex = 0;
        this.currentToken = tokens.get(currentTokenIndex);
        this.errors = errors;
    }

    private void nextToken() {
        if (currentTokenIndex < tokens.size() - 1) {
            currentTokenIndex++;
            currentToken = tokens.get(currentTokenIndex);
        }
    }

    private boolean match(TokenType expectedType) {
        if (currentToken.type == expectedType) {
            nextToken();
            return true;
        }
        return false;
    }

    public void parse() {
        json();
        if (currentToken.type != TokenType.EOF) {
            error("EOF expected");
        }
    }

    private void json() {
        element();
        if (currentToken.type != TokenType.EOF) {
            error("EOF expected");
        }
    }

    private void element() {
        if (currentToken.type == TokenType.L_LLAVE) {
            object();
        } else if (currentToken.type == TokenType.L_CORCHETE) {
            array();
        } else {
            error("Object or array expected");
        }
    }

    private void array() {
        if (match(TokenType.L_CORCHETE)) {
            if (currentToken.type == TokenType.R_CORCHETE) {
                match(TokenType.R_CORCHETE);
            } else {
                elementList();
                if (!match(TokenType.R_CORCHETE)) {
                    error("']' expected");
                }
            }
        } else {
            error("'[' expected");
        }
    }

    private void elementList() {
        element();
        while (currentToken.type == TokenType.COMA) {
            match(TokenType.COMA);
            element();
        }
    }

    private void object() {
        if (match(TokenType.L_LLAVE)) {
            if (currentToken.type == TokenType.R_LLAVE) {
                match(TokenType.R_LLAVE);
            } else {
                attributesList();
                if (!match(TokenType.R_LLAVE)) {
                    error("'}' expected");
                }
            }
        } else {
            error("'{' expected");
        }
    }

    private void attributesList() {
        attribute();
        while (currentToken.type == TokenType.COMA) {
            match(TokenType.COMA);
            attribute();
        }
    }

    private void attribute() {
        if (currentToken.type == TokenType.LITERAL_CADENA) {
            match(TokenType.LITERAL_CADENA);
            if (!match(TokenType.DOS_PUNTOS)) {
                error("':' expected");
            }
            attributeValue();
        } else {
            error("Attribute name expected");
        }
    }

    private void attributeValue() {
        if (currentToken.type == TokenType.LITERAL_CADENA || currentToken.type == TokenType.LITERAL_NUM ||
            currentToken.type == TokenType.PR_TRUE || currentToken.type == TokenType.PR_FALSE ||
            currentToken.type == TokenType.PR_NULL) {
            nextToken();
        } else {
            element();
        }
    }

    private void error(String message) {
        String errorMsg = "Error: " + message + " at token " + currentToken;
        System.out.println(errorMsg);
        errors.add(errorMsg);
        // Implementar Panic Mode para continuar el análisis
        while (currentToken.type != TokenType.COMA && currentToken.type != TokenType.R_LLAVE &&
               currentToken.type != TokenType.R_CORCHETE && currentToken.type != TokenType.EOF) {
            nextToken();
        }
        // Si es EOF, detener el análisis
        if (currentToken.type != TokenType.EOF) {
            nextToken();
        }
    }
}
