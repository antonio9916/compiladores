import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Lexer {
    public static List<Token> tokenize(String inputFile, List<String> errors) {
        List<Token> tokens = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                processLine(line.trim(), tokens, errors);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        tokens.add(new Token(TokenType.EOF, ""));
        return tokens;
    }

    private static void processLine(String line, List<Token> tokens, List<String> errors) {
        String regex = "\\{|\\}|\\[|\\]|,|:|\"(?:\\\\\"|[^\"])*\"|-?\\d+(?:\\.\\d+)?(?:[eE][-+]?\\d+)?|true|false|null";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(line);
        int lastMatchEnd = 0;
        while (matcher.find()) {
            String token = matcher.group().trim();
            if (!token.isEmpty()) {
                tokens.add(new Token(getTokenType(token), token));
                lastMatchEnd = matcher.end();
            } else {
                String error = "Error léxico en la línea: " + line.substring(lastMatchEnd);
                tokens.add(new Token(TokenType.ERROR, error));
                errors.add(error);
                return;
            }
        }

        if (lastMatchEnd < line.length()) {
            String error = "Error léxico en la línea: " + line.substring(lastMatchEnd);
            tokens.add(new Token(TokenType.ERROR, error));
            errors.add(error);
        }
    }

    private static TokenType getTokenType(String token) {
        switch (token) {
            case "{":
                return TokenType.L_LLAVE;
            case "}":
                return TokenType.R_LLAVE;
            case "[":
                return TokenType.L_CORCHETE;
            case "]":
                return TokenType.R_CORCHETE;
            case ",":
                return TokenType.COMA;
            case ":":
                return TokenType.DOS_PUNTOS;
            case "true":
                return TokenType.PR_TRUE;
            case "false":
                return TokenType.PR_FALSE;
            case "null":
                return TokenType.PR_NULL;
            default:
                if (token.matches("\"(?:\\\\\"|[^\"])*\"")) {
                    return TokenType.LITERAL_CADENA;
                } else if (token.matches("-?\\d+(\\.\\d+)?(?:[eE][-+]?\\d+)?")) {
                    return TokenType.LITERAL_NUM;
                } else {
                    return TokenType.ERROR;
                }
        }
    }
}
