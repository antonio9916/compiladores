import java.util.List;

public class Parser {
    private List<Token> tokens;
    private int currentTokenIndex;
    private Token currentToken;
    private List<String> errors;
    private StringBuilder xmlOutput;

    public Parser(List<Token> tokens, List<String> errors) {
        this.tokens = tokens;
        this.currentTokenIndex = 0;
        this.currentToken = tokens.get(currentTokenIndex);
        this.errors = errors;
        this.xmlOutput = new StringBuilder();
    }

    private void nextToken() {
        if (currentTokenIndex < tokens.size() - 1) {
            currentTokenIndex++;
            currentToken = tokens.get(currentTokenIndex);
        }
    }

    private boolean match(TokenType expectedType) {
        if (currentToken.type == expectedType) {
            nextToken();
            return true;
        }
        return false;
    }

    public void parse() {
        json();
        if (currentToken.type != TokenType.EOF) {
            error("EOF expected");
        }
    }

    private void json() {
        xmlOutput.append("<json>");
        element();
        xmlOutput.append("</json>");
        if (currentToken.type != TokenType.EOF) {
            error("EOF expected");
        }
    }

    private void element() {
        if (currentToken.type == TokenType.L_LLAVE) {
            object();
        } else if (currentToken.type == TokenType.L_CORCHETE) {
            array();
        } else {
            error("Object or array expected");
        }
    }

    private void array() {
        if (match(TokenType.L_CORCHETE)) {
            xmlOutput.append("<array>");
            if (currentToken.type == TokenType.R_CORCHETE) {
                match(TokenType.R_CORCHETE);
            } else {
                elementList();
                if (!match(TokenType.R_CORCHETE)) {
                    error("']' expected");
                }
            }
            xmlOutput.append("</array>");
        } else {
            error("'[' expected");
        }
    }

    private void elementList() {
        element();
        while (currentToken.type == TokenType.COMA) {
            match(TokenType.COMA);
            element();
        }
    }

    private void object() {
        if (match(TokenType.L_LLAVE)) {
            xmlOutput.append("<object>");
            if (currentToken.type == TokenType.R_LLAVE) {
                match(TokenType.R_LLAVE);
            } else {
                attributesList();
                if (!match(TokenType.R_LLAVE)) {
                    error("'}' expected");
                }
            }
            xmlOutput.append("</object>");
        } else {
            error("'{' expected");
        }
    }

    private void attributesList() {
        attribute();
        while (currentToken.type == TokenType.COMA) {
            match(TokenType.COMA);
            attribute();
        }
    }

    private void attribute() {
        if (currentToken.type == TokenType.LITERAL_CADENA) {
            String attributeName = currentToken.lexeme;
            match(TokenType.LITERAL_CADENA);
            if (!match(TokenType.DOS_PUNTOS)) {
                error("':' expected");
            }
            xmlOutput.append("<").append(attributeName).append(">");
            attributeValue();
            xmlOutput.append("</").append(attributeName).append(">");
        } else {
            error("Attribute name expected");
        }
    }

    private void attributeValue() {
        if (currentToken.type == TokenType.LITERAL_CADENA) {
            xmlOutput.append(currentToken.lexeme);
            match(TokenType.LITERAL_CADENA);
        } else if (currentToken.type == TokenType.LITERAL_NUM) {
            xmlOutput.append(currentToken.lexeme);
            match(TokenType.LITERAL_NUM);
        } else if (currentToken.type == TokenType.PR_TRUE || currentToken.type == TokenType.PR_FALSE || currentToken.type == TokenType.PR_NULL) {
            xmlOutput.append(currentToken.lexeme);
            match(currentToken.type);
        } else if (currentToken.type == TokenType.L_LLAVE || currentToken.type == TokenType.L_CORCHETE) {
            element();
        } else {
            error("Attribute value expected");
        }
    }

    private void error(String message) {
        errors.add("Error: " + message + " at token " + currentToken.lexeme);
        panicMode();
    }

    private void panicMode() {
        while (currentToken.type != TokenType.COMA && currentToken.type != TokenType.R_LLAVE && currentToken.type != TokenType.R_CORCHETE && currentToken.type != TokenType.EOF) {
            nextToken();
        }
        if (currentToken.type == TokenType.COMA || currentToken.type == TokenType.R_LLAVE || currentToken.type == TokenType.R_CORCHETE) {
            nextToken();
        }
    }

    public String getXmlOutput() {
        return xmlOutput.toString();
    }
}