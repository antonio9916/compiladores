import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JsonToXmlTranslator {

    public static void main(String[] args) {
        String inputFile = "fuente.json";
        String outputFile = "output.xml";
        List<String> errors = new ArrayList<>();

        // Tokenización
        List<Token> tokens = Lexer.tokenize(inputFile, errors);

        // Parsing
        Parser parser = new Parser(tokens, errors);
        parser.parse();

        // Output
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            if (errors.isEmpty()) {
                writer.write(parser.getXmlOutput());
            } else {
                for (String error : errors) {
                    writer.write(error);
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
